﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LianLianKan
{
	public class Data
	{

		static public int width = 10;
		static public int height = 6;
		static public int imageCount = 4;
		static public Image[] images;
		static public int imageSize = 45;
		static public int offset = 3;
	}

	
}
